
import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import GreenRoboAdvisor from './GreenRoboAdvisor'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GreenRoboAdvisor />
  </React.StrictMode>,
)
