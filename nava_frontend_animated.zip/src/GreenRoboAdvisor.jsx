import React, { useState } from "react";

export default function GreenRoboAdvisor() {
  const [etfs, setEtfs] = useState([]);
  const [strategy, setStrategy] = useState("min_var");
  const [startDate, setStartDate] = useState("2021-04-01");
  const [endDate, setEndDate] = useState("2025-04-01");
  const [benchmark, setBenchmark] = useState("MSCI World SRI");
  const [useSmoothing, setUseSmoothing] = useState(false);
  const [allocationType, setAllocationType] = useState("dynamic");
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    const response = await fetch("/api/optimize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        etfs,
        strategy,
        startDate,
        endDate,
        benchmark,
        useSmoothing,
        allocationType
      })
    });
    const data = await response.json();
    setResult(data);
  };

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-green-700">🌱 Green Robo Advisor</h1>

      <div className="bg-gray-100 rounded-xl p-4 space-y-4">
        <div>
          <label className="font-semibold">ETF selection (comma-separated)</label>
          <input
            className="w-full border p-2 rounded"
            placeholder="e.g., iShares, Lyxor"
            value={etfs.join(",")}
            onChange={(e) => setEtfs(e.target.value.split(","))}
          />
        </div>

        <div>
          <label className="font-semibold">Strategy</label>
          <select
            className="w-full border p-2 rounded"
            value={strategy}
            onChange={(e) => setStrategy(e.target.value)}
          >
            <option value="min_var">Minimum Variance</option>
            <option value="max_sharpe">Max Sharpe Ratio</option>
            <option value="max_return">Max Expected Return</option>
          </select>
        </div>

        <div>
          <label className="font-semibold">Allocation Type</label>
          <select
            className="w-full border p-2 rounded"
            value={allocationType}
            onChange={(e) => setAllocationType(e.target.value)}
          >
            <option value="static">Static</option>
            <option value="dynamic">Dynamic</option>
          </select>
        </div>

        <div className="flex gap-4">
          <div className="flex-1">
            <label className="font-semibold">Start Date</label>
            <input
              className="w-full border p-2 rounded"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>

          <div className="flex-1">
            <label className="font-semibold">End Date</label>
            <input
              className="w-full border p-2 rounded"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="font-semibold">Benchmark</label>
          <input
            className="w-full border p-2 rounded"
            placeholder="e.g., MSCI World SRI"
            value={benchmark}
            onChange={(e) => setBenchmark(e.target.value)}
          />
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={useSmoothing}
            onChange={(e) => setUseSmoothing(e.target.checked)}
          />
          <label className="font-medium">Use EMA Smoothing</label>
        </div>

        <button
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          onClick={handleSubmit}
        >
          Run Optimization
        </button>
      </div>

      {result && (
        <div className="bg-white shadow rounded-xl p-4 space-y-2">
          <h2 className="text-xl font-semibold text-green-600">📊 Results</h2>
          <p>Expected Return: {result.expected_return.toFixed(2)}%</p>
          <p>Variance: {result.variance.toFixed(4)}</p>
          <p>Sharpe Ratio: {result.sharpe_ratio?.toFixed(2)}</p>
          <p>CVaR: {result.cvar?.toFixed(2)}%</p>
          <p>Max Drawdown: {result.max_drawdown?.toFixed(2)}%</p>

          <div>
            <h3 className="font-medium">Weights:</h3>
            <ul className="list-disc pl-5">
              {Object.entries(result.weights).map(([etf, weight]) => (
                <li key={etf}>{etf}: {(weight * 100).toFixed(2)}%</li>
              ))}
            </ul>
          </div>

          <div className="mt-4">
            <h3 className="font-medium">Backtesting Plot</h3>
            <div className="border rounded p-2 bg-gray-50 text-center">
              <em>Backtesting graph placeholder</em>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
